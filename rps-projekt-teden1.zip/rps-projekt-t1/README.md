# Šolski IS – podpora šolskemu delu na daljavo

Projekt pri predmetu RPS – Računalniški produkti in storitve.
**Stanje: oddaja za 1. teden** (analiza, načrtovanje in priprava okolja).

## Skupina
| Član | Vloga |
|------|-------|
| Jernej Robnik | Vzdrževalec IS |
| Vid Strmčnik | Razvijalec |
| Lan Plazar | Razvijalec |

Mentor: Andraž Pušnik

## Opis
Spletna aplikacija s tremi pogledi (administrator, učitelj, učenec). Teče v Docker vsebnikih na Linux strežniku in bo objavljena na javni domeni prek HTTPS. V 1. tednu je pripravljena analiza, specifikacija, ER diagram, skice in osnovno razvojno okolje; razvoj same aplikacije se začne v 2. tednu.

## Struktura repozitorija
```
aplikacija/   prazno - koda se doda od 2. tedna naprej
baza/         prazno - SQL skripte se dodajo v 2. tednu
docs/         specifikacija, ER diagram, skice
porocila/     dnevna in tedensko poročilo za 1. teden
docker-compose.yml   osnutek - samo podatkovna baza
.env.example
```

## Zagon razvojnega okolja (1. teden)
```
cp .env.example .env
docker compose up -d
```
Zažene se samo vsebnik s podatkovno bazo MariaDB; s tem je preverjeno, da Docker okolje deluje.

## Dokumentacija
- [Specifikacija](docs/specifikacija.md)
- [ER diagram](docs/er-diagram.md)
- [Skice (wireframe)](docs/wireframes.md)
- [Tedensko poročilo – 1. teden](porocila/teden-1.md)

## Pravila dela z Gitom
- Veji: `main` (stabilna) in `develop` (od 2. tedna); delo poteka na vejah `feature/ime-funkcije`.
- Spremembe v `main` samo prek vlečnih zahtevkov (pull request) s pregledom drugega člana.
- Jasna sporočila commitov, napake v GitHub Issues.
